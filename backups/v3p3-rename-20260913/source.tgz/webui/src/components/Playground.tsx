import { useCallback, useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { api, Character, Conversation, GpuReport, Memory, Message, OllamaModel, CharacterProfile } from "../api";
import { useI18n, LanguageSwitch } from "../i18n";
import CharacterForm from "./CharacterForm";
import ChatPanel from "./ChatPanel";
import BenchmarkPanel from "./BenchmarkPanel";
import CharacterAvatar from "./CharacterAvatar";
import Lightbox from "./Lightbox";

type Fan = { id: string; name: string; notes: string };
type ModelMetric = { model: string; samples: number; mean_seconds: number; median_seconds: number; mean_load_seconds: number };
const gb = (bytes: number) => `${(bytes / 1024 ** 3).toFixed(1)} GB`;

export default function Playground({ onLogout }: { onLogout: () => void }) {
  const { t, lang } = useI18n();
  const failure = (err: unknown) => (err instanceof Error ? err.message : t("common.failed"));
  const [characters, setCharacters] = useState<Character[]>([]);
  const [fans, setFans] = useState<Fan[]>([]);
  const [models, setModels] = useState<OllamaModel[]>([]);
  const [characterId, setCharacterId] = useState("");
  const [fanId, setFanId] = useState("");
  const [model, setModel] = useState("");
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [conversation, setConversation] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [memories, setMemories] = useState<Memory[]>([]);
  const [metrics, setMetrics] = useState<ModelMetric[]>([]);
  const [busy, setBusy] = useState("");
  const [elapsed, setElapsed] = useState(0);
  const [error, setError] = useState("");
  const [editing, setEditing] = useState<Character | "new" | null>(null);
  const [fanEditor, setFanEditor] = useState<Fan | "new" | null>(null);
  const [fanName, setFanName] = useState("");
  const [fanNotes, setFanNotes] = useState("");
  const [tab, setTab] = useState<"chat" | "benchmark">("chat");
  const [checkpoints, setCheckpoints] = useState<string[]>([]);
  const [photoOpen, setPhotoOpen] = useState(false);
  const [photoScene, setPhotoScene] = useState("");
  const [photoCaption, setPhotoCaption] = useState("");
  const [viewer, setViewer] = useState<{ url: string; alt: string } | null>(null);
  const [gpu, setGpu] = useState<GpuReport | null>(null);
  const [absence, setAbsence] = useState(48);
  const [autoNudge, setAutoNudge] = useState(false);
  const [lastActivity, setLastActivity] = useState(Date.now());
  const [newMemory, setNewMemory] = useState("");
  const [historyPage, setHistoryPage] = useState(1);
  const generation = useRef(0);
  const character = characters.find(c => c.id === characterId);
  const fan = fans.find(f => f.id === fanId);
  const chatModels = models.filter(m => m.chat_capable !== false && !m.name.toLowerCase().includes("embed"));
  const scope = `fan_id=${encodeURIComponent(fanId)}`;

  useEffect(() => {
    let live = true;
    Promise.all([api.getCharacters(), api.request<Fan[]>("/api/fans"), api.getModels(), api.getCheckpoints()])
      .then(([chars, people, data, imageModels]) => {
        if (!live) return;
        setCharacters(chars); setFans(people); setModels(data.models); setCheckpoints(imageModels.checkpoints);
        setCharacterId(chars[0]?.id || "");
        setFanId(people.find(f => f.id !== "legacy")?.id || people[0]?.id || "");
        setModel(data.models.find(m => m.name === "llama3.1:8b")?.name || data.models.find(m => m.chat_capable !== false)?.name || "");
      }).catch(e => { if (live) setError(failure(e)); });
    return () => { live = false; };
  }, []);

  useEffect(() => {
    generation.current += 1;
    const epoch = generation.current;
    setConversation(null); setMessages([]); setConversations([]); setMemories([]); setMetrics([]); setAutoNudge(false);
    if (!characterId || !fanId) return;
    Promise.all([
      api.request<Conversation[]>(`/api/characters/${characterId}/conversations?${scope}`),
      api.request<Memory[]>(`/api/characters/${characterId}/memories?${scope}`),
      api.request<ModelMetric[]>(`/api/metrics/models?character_id=${characterId}&${scope}`),
    ]).then(([chats, facts, stats]) => {
      if (generation.current !== epoch) return;
      setConversations(chats); setMemories(facts); setMetrics(stats);
    }).catch(e => { if (generation.current === epoch) setError(failure(e)); });
  }, [characterId, fanId, scope]);

  useEffect(() => {
    let live = true;
    const load = () => api.getGpuStatus().then(data => { if (live) setGpu(data); }).catch(() => undefined);
    void load();
    const timer = window.setInterval(() => void load(), 3000);
    return () => { live = false; window.clearInterval(timer); };
  }, []);

  useEffect(() => {
    if (!busy) { setElapsed(0); return; }
    const start = Date.now();
    const timer = window.setInterval(() => setElapsed((Date.now() - start) / 1000), 100);
    return () => window.clearInterval(timer);
  }, [busy]);

  const refresh = useCallback(async (id: string) => {
    const epoch = generation.current;
    const [chat, msgs, facts, chats, stats] = await Promise.all([
      api.request<Conversation>(`/api/conversations/${id}`),
      api.request<Message[]>(`/api/conversations/${id}/messages?limit=500`),
      api.request<Memory[]>(`/api/characters/${characterId}/memories?${scope}`),
      api.request<Conversation[]>(`/api/characters/${characterId}/conversations?${scope}`),
      api.request<ModelMetric[]>(`/api/metrics/models?character_id=${characterId}&${scope}`),
    ]);
    if (epoch !== generation.current) return;
    setConversation(chat); setMessages(msgs); setMemories(facts); setConversations(chats); setMetrics(stats);
  }, [characterId, scope]);

  useEffect(() => {
    if (!conversation || conversation.memory_status !== "pending") return;
    const id = conversation.id, epoch = generation.current;
    let stopped = false, tries = 0;
    const timer = window.setInterval(async () => {
      if (stopped || ++tries > 100) { window.clearInterval(timer); return; }
      try {
        const current = await api.request<Conversation>(`/api/conversations/${id}`);
        if (stopped || generation.current !== epoch) return;
        setConversation(current);
        if (current.memory_status !== "pending") {
          const facts = await api.request<Memory[]>(`/api/characters/${characterId}/memories?${scope}`);
          if (!stopped && generation.current === epoch) setMemories(facts);
          window.clearInterval(timer);
        }
      } catch { window.clearInterval(timer); }
    }, 2500);
    return () => { stopped = true; window.clearInterval(timer); };
  }, [conversation?.id, conversation?.memory_status, characterId, scope]);

  const perform = async (label: string, work: () => Promise<void>) => {
    if (busy) return;
    setBusy(label); setError("");
    try { await work(); } catch (e) { setError(failure(e)); } finally { setBusy(""); }
  };

  const startChat = () => perform(t("pg.busy.prepareFirst"), async () => {
    const chat = await api.request<Conversation>(`/api/characters/${characterId}/conversations`, {
      method: "POST", body: JSON.stringify({ model, fan_id: fanId, auto_greet: true }) });
    setConversation(chat); setHistoryPage(1); setLastActivity(Date.now());
    await refresh(chat.id);
    if (chat.greeting_error) setError(t("pg.greetingError", { error: chat.greeting_error }));
  });

  const send = async (content: string) => {
    if (!conversation || busy) return false;
    const id = conversation.id;
    setMessages(prev => [...prev, { id: "pending", conversation_id: id, role: "user", content,
      model: null, ollama_metrics: null, created_at: new Date().toISOString() }]);
    setBusy(t("pg.busy.writing")); setError(""); setLastActivity(Date.now());
    try {
      await api.sendMessage(id, content);
      await refresh(id); return true;
    } catch (e) {
      setMessages(prev => prev.filter(m => m.id !== "pending")); setError(failure(e)); return false;
    } finally { setBusy(""); }
  };

  const initiate = useCallback(async (kind: "opener" | "reengage") => {
    if (!conversation || busy) return;
    setBusy(kind === "opener" ? t("pg.busy.prepareFirst") : t("pg.busy.checkin")); setError("");
    setLastActivity(Date.now());
    try {
      await api.request(`/api/conversations/${conversation.id}/initiate`, {
        method: "POST", body: JSON.stringify({ kind, absence_hours: absence }) });
      await refresh(conversation.id);
    } catch (e) { setError(failure(e)); } finally { setBusy(""); }
  }, [conversation, busy, absence, refresh]);

  useEffect(() => {
    if (!autoNudge || !conversation || busy || tab !== "chat") return;
    const timeout = window.setTimeout(() => { setAutoNudge(false); void initiate("reengage"); },
      Math.max(1000, 60000 - (Date.now() - lastActivity)));
    return () => window.clearTimeout(timeout);
  }, [autoNudge, conversation, busy, lastActivity, initiate, tab]);

  const saveCharacter = async (data: { name: string; profile: CharacterProfile }) => {
    const saved = editing && editing !== "new" ? await api.updateCharacter(editing.id, data) : await api.createCharacter(data);
    setCharacters(prev => [...prev.filter(c => c.id !== saved.id), saved]);
    setCharacterId(saved.id); setEditing(null);
  };

  const removeCharacter = () => {
    if (!character || !window.confirm(t("pg.deleteCharacterConfirm", { name: character.name }))) return;
    void perform(t("pg.busy.deleteCharacter"), async () => {
      await api.deleteCharacter(character.id); setCharacters(prev => prev.filter(c => c.id !== character.id)); setCharacterId("");
    });
  };

  const duplicateCharacter = () => {
    if (!character) return;
    void perform(t("pg.busy.duplicate"), async () => {
      const copy = await api.cloneCharacter(character.id, `${character.name} ${t("pg.copySuffix")}`);
      setCharacters(prev => [...prev, copy]); setCharacterId(copy.id);
    });
  };

  const generateAvatar = () => {
    if (!character) return;
    void perform(t("pg.busy.avatar"), async () => {
      const updated = await api.generateAvatar(character.id);
      setCharacters(prev => prev.map(item => (item.id === updated.id ? updated : item)));
    });
  };

  const openFan = (value: Fan | "new") => {
    setFanEditor(value); setFanName(value === "new" ? "" : value.name); setFanNotes(value === "new" ? "" : value.notes);
  };

  return <div className="playground">
    <header className="topbar"><div className="brand"><span className="brand-mark">ai</span><h1>AI influencer playground <b>v3.2</b></h1></div>
      <div className="top-actions"><span className="sandbox-label">{t("pg.sandbox")}</span><nav className="top-nav"><Link className="selected" to="/">{t("pg.nav.chat")}</Link><Link to="/images">{t("pg.nav.images")}</Link></nav><LanguageSwitch /><button onClick={onLogout} disabled={!!busy}>{t("pg.logout")}</button></div></header>
    {error && <div className="error-banner" role="alert">{error}<button onClick={() => setError("")} aria-label={t("pg.error.closeAria")}>×</button></div>}
    <div className="workspace">
      <aside className="character-rail">
        <div className="section-title"><h2>{t("pg.characters")} <span>{characters.length}</span></h2><button aria-label={t("pg.createCharacter")} onClick={() => setEditing("new")} disabled={!!busy}>+</button></div>
        <div className="character-list">{characters.map((c, index) => <button key={c.id} disabled={!!busy} onClick={() => setCharacterId(c.id)} className={`character-row ${characterId === c.id ? "selected" : ""}`}>
          <CharacterAvatar character={c} index={index} onView={(url, alt) => setViewer({ url, alt })} altTemplate={t("pg.avatarAlt")} /><span><strong>{c.name}</strong><small>{c.profile.personality_traits || t("pg.noTraits")}</small></span></button>)}
          {!characters.length && <p className="muted">{t("pg.noCharacters")}</p>}</div>
        {character && <div className="character-actions"><button onClick={() => setEditing(character)} disabled={!!busy}>{t("pg.editPersonality")}</button><button onClick={duplicateCharacter} disabled={!!busy} title={t("pg.duplicateTitle")}>{t("pg.duplicate")}</button><button onClick={generateAvatar} disabled={!!busy} title={t("pg.avatarTitle")}>{t("pg.avatar")}</button><button className="danger" onClick={removeCharacter} disabled={!!busy}>{t("common.delete")}</button></div>}
        {character && <label className="image-checkpoint">{t("pg.imageStyle")}<select value={character.image_style || "real"} disabled={!!busy} onChange={e => void perform(t("pg.busy.style"), async () => {
          const updated = await api.setImageStyle(character.id, e.target.value as "anime" | "real");
          setCharacters(prev => prev.map(item => (item.id === updated.id ? updated : item)));
        })}><option value="real">{t("pg.style.real")}</option><option value="anime">{t("pg.style.anime")}</option></select></label>}
        {character && checkpoints.length > 0 && <label className="image-checkpoint">{t("pg.checkpoint")}<select value={character.image_checkpoint || ""} disabled={!!busy} onChange={e => void perform(t("pg.busy.checkpoint"), async () => {
          const updated = await api.setImageCheckpoint(character.id, e.target.value || null);
          setCharacters(prev => prev.map(item => (item.id === updated.id ? updated : item)));
        })}><option value="">{t("pg.checkpointDefault")}</option>{checkpoints.map(name => <option key={name} value={name}>{name}</option>)}</select></label>}
        <div className="rail-divider" />
        <div className="section-title"><h2>{t("pg.playFan")}</h2><button aria-label={t("pg.createFan")} onClick={() => openFan("new")} disabled={!!busy}>+</button></div>
        <label className="sr-only" htmlFor="fan-select">{t("pg.fanAccount")}</label><select id="fan-select" value={fanId} onChange={e => setFanId(e.target.value)} disabled={!!busy}>
          <option value="" disabled>{t("pg.chooseFan")}</option>{fans.map(f => <option key={f.id} value={f.id}>{f.name}</option>)}</select>
        {fan && <div className="fan-note"><div><span>{t("pg.fanNotes")}</span><button onClick={() => openFan(fan)} disabled={!!busy}>{t("common.edit")}</button></div><p>{fan.notes || t("pg.noNotes")}</p><small>{t("pg.notesHint")}</small></div>}
        <div className="section-title history-title"><h2>{t("pg.conversations")}</h2><span>{conversations.length}</span></div>
        <div className="history-list">{conversations.slice(0, historyPage * 10).map(c => <button className={conversation?.id === c.id ? "selected" : ""} key={c.id} disabled={!!busy}
          onClick={() => void perform(t("pg.busy.loadChat"), async () => { generation.current += 1; setMessages([]); setAutoNudge(false); setConversation(c); setModel(c.model); await refresh(c.id); })}>
          <strong>{c.model}</strong><small>{new Date(c.created_at).toLocaleString(lang === "it" ? "it-IT" : "en-GB", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })} · v{c.character_snapshot.version}</small></button>)}
          {conversations.length > historyPage * 10 && <button onClick={() => setHistoryPage(p => p + 1)}>{t("pg.showMore")}</button>}
          {!conversations.length && <p className="muted">{t("pg.noChats")}</p>}</div>
      </aside>
      <main className="main-panel">
        <div className="chat-heading"><div><span className="eyebrow">{character ? t("pg.personalityVersion", { version: character.version }) : t("pg.lab")}</span><h2>{character?.name || t("pg.chooseCharacter")}</h2><p>{fan ? t("pg.withFan", { name: fan.name }) : t("pg.createFanHint")}</p></div>
          <div className="view-tabs" role="tablist"><button role="tab" aria-selected={tab === "chat"} onClick={() => setTab("chat")} disabled={!!busy}>{t("pg.tab.chat")}</button><button role="tab" aria-selected={tab === "benchmark"} onClick={() => setTab("benchmark")} disabled={!!busy}>{t("pg.tab.benchmark")}</button></div></div>
        {tab === "chat" ? <>
          <div className="model-toolbar"><label htmlFor="model-select">{t("pg.model")}</label><select id="model-select" value={model} disabled={!!busy} onChange={e => setModel(e.target.value)}>
            <option value="" disabled>{t("pg.chooseModel")}</option>{chatModels.map(m => <option key={m.name} value={m.name}>{m.name} · {m.parameter_size}</option>)}</select>
            <button className="primary" onClick={startChat} disabled={!character || !fan || !model || !!busy}>{t("pg.newChat")}</button>
            {conversation && model !== conversation.model && <button disabled={!!busy} onClick={() => void perform(t("pg.busy.changeModel"), async () => {
              const updated = await api.request<Conversation>(`/api/conversations/${conversation.id}`, { method: "PATCH", body: JSON.stringify({ model }) }); setConversation(updated);
            })}>{t("pg.useInChat")}</button>}</div>
          {conversation && conversation.character_snapshot.version !== character?.version && <div className="info-banner">{t("pg.snapshotWarning", { version: conversation.character_snapshot.version })}</div>}
          <ChatPanel conversation={conversation} messages={messages} onSendMessage={send} loading={!!busy} busyLabel={busy} elapsed={elapsed} fanName={fan?.name || t("pg.fanFallback")} />
          {conversation && <div className="initiative-bar">
            <div className="quick-actions">
              <button disabled={!!busy} onClick={() => void initiate("opener")} title={t("pg.quick.openTitle")}>{t("pg.quick.open")}</button>
              <button disabled={!!busy} onClick={() => void initiate("reengage")} title={t("pg.quick.checkinTitle")}>{t("pg.quick.checkin")}</button>
              <button disabled={!!busy} title={t("pg.manualPhotoTitle")} onClick={() => { setPhotoScene(""); setPhotoCaption(""); setPhotoOpen(true); }}>{t("pg.manualPhoto")}</button>
              <label className="toggle-pill" title={t("pg.autoPhotoTitle")}><input type="checkbox" checked={conversation.images_enabled !== false} disabled={!!busy} onChange={e => void perform(t("pg.busy.images"), async () => {
                const updated = await api.updateConversation(conversation.id, { images_enabled: e.target.checked });
                setConversation(updated);
              })} /> {t("pg.autoPhoto")}</label>
            </div>
            <details className="tool-menu"><summary>{t("pg.options")}</summary><div className="tool-menu-body">
              <label>{t("pg.absence")} <input aria-label={t("pg.absenceAria")} type="number" min="1" max="8760" value={absence} onChange={e => setAbsence(Math.max(1, Math.min(8760, Number(e.target.value))))} /> h</label>
              <label className="auto-label"><input type="checkbox" checked={autoNudge} onChange={e => { setAutoNudge(e.target.checked); setLastActivity(Date.now()); }} disabled={!!busy} /> {t("pg.nudge")}</label>
              <button className="danger" type="button" disabled={!!busy} onClick={() => {
                if (!window.confirm(t("pg.deleteChatConfirm"))) return;
                void perform(t("pg.busy.deleteChat"), async () => { await api.request(`/api/conversations/${conversation.id}`, { method: "DELETE" }); setConversations(prev => prev.filter(c => c.id !== conversation.id)); setConversation(null); setMessages([]); });
              }}>{t("pg.deleteChat")}</button>
            </div></details>
          </div>}
        </> : <BenchmarkPanel character={character} fanId={fanId} models={chatModels} onBusy={setBusy} />}
      </main>
      <aside className="inspector">
        <div className="section-title"><h2>{t("pg.gpu.title")}</h2><span>{gpu?.gpus.length ?? 0}</span></div>
        {gpu?.available ? <div className="gpu-list">{gpu.gpus.map(item => <article className="gpu-card" key={item.index}>
          <header><strong>GPU {item.index} · {item.name.replace("NVIDIA GeForce ", "")}</strong><span>{item.temperature != null ? `${item.temperature}°C` : ""}</span></header>
          <div className="gpu-bar" title={`${gb(item.memory_used)} / ${gb(item.memory_total)}`}><i style={{ width: `${Math.min(100, (item.memory_used / item.memory_total) * 100)}%` }} /></div>
          <small>{gb(item.memory_used)} / {gb(item.memory_total)} · {item.utilization}% util{item.power_watts != null ? ` · ${item.power_watts} W` : ""}</small>
          {!!item.processes.length && <ul>{item.processes.map(process => <li key={`${item.index}-${process.pid}-${process.name}`}><span title={process.name}>{process.name}</span><b>{gb(process.vram)}</b></li>)}</ul>}
        </article>)}</div> : <p className="muted">{gpu === null ? t("pg.gpu.loading") : t("pg.gpu.unavailable")}</p>}
        <div className="rail-divider" />
        <div className="section-title"><h2>{t("pg.memory.title")}</h2><span>{memories.length}</span></div>
        <p className="scope-label">{character?.name || t("pg.characterFallback")} × {fan?.name || "Fan"}</p>
        {conversation?.memory_status === "pending" && <p className="memory-status" role="status"><span className="spinner" /> {t("pg.memory.extracting")}</p>}
        {conversation?.memory_status === "failed" && <p className="memory-status warning">{t("pg.memory.failed")}</p>}
        <div className="memory-list">{memories.map(m => <article key={m.id}><div><span>{m.embedding_model === "manual" ? t("pg.memory.manual") : t("pg.memory.fromChat")} · {m.importance}/5</span><button aria-label={`${t("pg.busy.deleteMemory")}: ${m.content}`} disabled={!!busy} onClick={() => void perform(t("pg.busy.deleteMemory"), async () => { await api.deleteMemory(m.id); setMemories(prev => prev.filter(x => x.id !== m.id)); })}>×</button></div><p>{m.content}</p></article>)}
          {!memories.length && <div className="empty-memory"><span>◎</span><p>{t("pg.memory.empty")}</p><small>{t("pg.memory.emptyHint")}</small></div>}</div>
        {character && fan && <><form className="memory-form" onSubmit={e => { e.preventDefault(); void perform(t("pg.busy.saveMemory"), async () => {
          const saved = await api.request<Memory>(`/api/characters/${characterId}/memories?${scope}`, { method: "POST", body: JSON.stringify({ content: newMemory, category: "personal_fact", importance: 3 }) });
          setMemories(prev => [...prev.filter(m => m.id !== saved.id), saved]); setNewMemory("");
        }); }}><label htmlFor="memory-input">{t("pg.memory.add")}</label><textarea id="memory-input" rows={2} value={newMemory} onChange={e => setNewMemory(e.target.value)} placeholder={t("pg.memory.placeholder")} maxLength={5000} /><button disabled={!!busy || !newMemory.trim()}>{t("pg.memory.save")}</button></form>
          {!!memories.length && <button className="text-button danger" disabled={!!busy} onClick={() => {
            if (!window.confirm(t("pg.memory.clearConfirm", { fan: fan.name, character: character.name }))) return;
            void perform(t("pg.busy.clearMemory"), async () => { await api.request(`/api/characters/${characterId}/memories?${scope}`, { method: "DELETE" }); setMemories([]); });
          }}>{t("pg.memory.clear")}</button>}</>}
        <div className="rail-divider" /><div className="section-title"><h2>{t("pg.times.title")}</h2></div>
        <p className="muted">{t("pg.times.note")}</p>
        <div className="metric-list">{metrics.map(m => <article key={m.model}><strong>{m.model}</strong><div><b>{m.mean_seconds.toFixed(2)} s</b><span>{t("pg.times.mean", { count: m.samples })}</span></div><small>{t("pg.times.detail", { median: m.median_seconds.toFixed(2), load: m.mean_load_seconds.toFixed(2) })}</small></article>)}
          {!metrics.length && <p className="muted">{t("pg.times.empty")}</p>}</div>
      </aside>
    </div>
    {editing && <div className="modal-backdrop"><div className="modal" role="dialog" aria-modal="true" aria-label={t("form.aria")}><CharacterForm character={editing === "new" ? undefined : editing} models={chatModels} onSave={saveCharacter} onCancel={() => setEditing(null)} /></div></div>}
    {photoOpen && conversation && <div className="modal-backdrop"><form className="modal fan-editor photo-editor" role="dialog" aria-modal="true" aria-label={t("pg.photo.title")} onSubmit={e => { e.preventDefault(); const scene = photoScene.trim() || undefined; const caption = photoCaption.trim() || undefined; setPhotoOpen(false); void perform(t("pg.busy.photo"), async () => {
      await api.sendPhoto(conversation.id, { scene, caption });
      await refresh(conversation.id);
    }); }}><h2>{t("pg.photo.title")}</h2><p className="muted">{t("pg.photo.note", { reference: character?.avatar_filename ? t("pg.photo.reference") : "" })}</p><label>{t("pg.photo.scene")}<textarea autoFocus rows={3} value={photoScene} onChange={e => setPhotoScene(e.target.value)} maxLength={1500} placeholder={t("pg.photo.scenePlaceholder")} /></label><label>{t("pg.photo.caption")}<input value={photoCaption} onChange={e => setPhotoCaption(e.target.value)} maxLength={1000} placeholder={t("pg.photo.captionPlaceholder")} /></label><div className="modal-actions"><button type="button" onClick={() => setPhotoOpen(false)} disabled={!!busy}>{t("common.cancel")}</button><button className="primary" disabled={!!busy}>{t("pg.photo.generate")}</button></div></form></div>}
    {fanEditor && <div className="modal-backdrop"><form className="modal fan-editor" role="dialog" aria-modal="true" aria-label={t("pg.fanAccount")} onSubmit={e => { e.preventDefault(); void perform(t("pg.busy.saveFan"), async () => {
      const saved = await api.request<Fan>(fanEditor === "new" ? "/api/fans" : `/api/fans/${fanEditor.id}`, { method: fanEditor === "new" ? "POST" : "PUT", body: JSON.stringify({ name: fanName, notes: fanNotes }) });
      setFans(prev => [...prev.filter(f => f.id !== saved.id), saved]); setFanId(saved.id); setFanEditor(null);
    }); }}><h2>{fanEditor === "new" ? t("pg.fan.new") : t("pg.fan.edit")}</h2><label>{t("pg.fan.name")}<input autoFocus value={fanName} onChange={e => setFanName(e.target.value)} required maxLength={120} /></label><label>{t("pg.fan.notes")}<textarea rows={5} value={fanNotes} onChange={e => setFanNotes(e.target.value)} maxLength={3000} /></label><p className="muted">{t("pg.fan.hint")}</p><div className="modal-actions"><button type="button" onClick={() => setFanEditor(null)} disabled={!!busy}>{t("common.cancel")}</button><button className="primary" disabled={!!busy}>{busy || t("pg.fan.save")}</button></div>{fanEditor !== "new" && <button className="danger text-button" type="button" disabled={!!busy} onClick={() => {
      if (!window.confirm(t("pg.fan.deleteConfirm"))) return;
      void perform(t("pg.busy.deleteFan"), async () => { await api.request(`/api/fans/${fanEditor.id}`, { method: "DELETE" }); setFans(prev => prev.filter(f => f.id !== fanEditor.id)); setFanId(""); setFanEditor(null); });
    }}>{t("pg.fan.delete")}</button>}</form></div>}
    {viewer && <Lightbox src={viewer.url} alt={viewer.alt} onClose={() => setViewer(null)} />}
  </div>;
}
